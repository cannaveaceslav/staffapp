package com.staffapp.mobile.model;

public enum UserRole {
    USER,
    ADMIN
}
